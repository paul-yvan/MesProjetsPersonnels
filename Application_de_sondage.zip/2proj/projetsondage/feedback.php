<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";

try {
    $bdd = new PDO("mysql:host=$servername;dbname=fin_annee_projet", $username, $password);
    // set the PDO error mode to exception
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
@$ch = $_POST["ch"];
@$soumission = $_POST["soumission"];
@$compteutilisateur = $_POST["compteutilisateur"];
@$description =  $_POST["description"];

if(isset($soumission)){


    for($i=0; $i <count($ch);$i++){

        $req=$bdd->prepare("insert into reponse (intitule) values (?)");
        $req->execute(array($ch[$i]));

    }

    if(isset($compteutilisateur)){

        $rep=$bdd->prepare("insert into reponse (intitule) values (?)");
        $rep->execute(array($compteutilisateur));

    }
    if(isset($description)){
        $rep=$bdd->prepare("insert into reponse (intitule) values (?)");
        $rep->execute(array($description));

    }


    

    
    


        
}

?>
<html>

    <head>
        <title>Page de feedback </title>
              
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <link href="https://fonts.googleapis.com/css?family=Poppins:500&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <meta charset = "utf-8"/>
        <style type="text/css">

        body{
            background:#eee;
            font-family: 'Poppins', sans-serif;
            
        }
        :root{
            --bg-color:white;
            --text-color:rgb(41, 41, 41);
        }
        body{
                background-color: 433f99;
                color: var(--text-color);
            }
        .wrapper{
            margin: 80px;
        }
        .form-signin{
            max-width:380px;
            margin: 0 auto;
            background-color:D3CBD8;
            padding:15px 40px 50px;
            border:1px solid #e5e5e5;
            border-radius:10px;
        }
       
        .form-signin .form-control{
            padding:10px;
        }
        h2{
            font-family: 'Poppins', sans-serif;
        }
        fieldset ul li {
            display:inline;
            
        }
        fieldset{
            border-radius:5px;
        }
        .mon_texte{
            text-align: justify;
        }
        
        textarea {
            width:100%;4444444
            font-size: .8rem;
            letter-spacing: 1px;
            padding: 10px;
            line-height: 1.5;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-shadow: 1px 1px 1px #999;
        }

        .bouton_soumettre {
            
            margin-top:50px;
            border: 0;
            line-height: 2.5;
            padding: 0 20px;
            font-size: 1.2rem;
            text-align: center;
            color: #fff;
            
            border-radius: 5px;
            background-color: #32be8f;
           
            
        }

        a{
            display: block;
            text-align: right;
            text-decoration: none;
            color: #999;
            font-size: 0.9rem;
            transition: .3s;
        }

        a:hover{
            color: #38d39f;
            text-decoration:none;
        }

        .retour a{

            text-align:left;
            margin-top:50px;
            margin-left:50px;

        }


        .bouton_soumettre:hover {
            background-image: linear-gradient(to right, #32be8f, #38d39f, #32be8f);
        }

        .bouton_soumettre:active {
            box-shadow: inset -2px -2px 3px rgba(255, 255, 255, .6),
                        inset 2px 2px 3px rgba(0, 0, 0, .6);
        }

        .speed-dial{
            position:fixed;
            bottom:15px;
            right:15px;
        }
        .speed-dial__options{
            position:absolute;
            bottom:100%;
            width:100%;
            text-align:center;
        }

        .speed-dial__button{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            padding:12px;
            margin-bottom:15px;
            background: #cccccc;
            color: #333333;
            border-radius:50%;
            box-shadow:1px 1px 2px rgba(0,0,0,0.5);
            cursor:pointer;
            text-decoration:none;
            -webkit-tap-highlight-color:transparent;
            border:none;
            outline:none;
            transition: background 0.2s, opacity 0.2s, transform 0.2s; 

        }

        .speed-dial__button:active{
            background: #aaaaaa;
        }

        .speed-dial__button--primary{
            margin-bottom:0;
            padding:18px;
            background:#38d39f;
            color:#ffffff;
        }

        .speed-dial__button--primary:active{
            background:rgba(44, 1, 124, 0.986);
        }

        .speed-dial__button:not(.speed-dial__button--primary){
            opacity:0;
            transform:translateY(40px);
            visibility:hidden;
        }
        .speed-dial--active .speed-dial__button{
            opacity:1;
            transform:translateY(0);
            visibility:visible;
        }

        @media(prefers-color-scheme: dark){
            :root{
                --bg-color:rgb(41, 41, 41);
                --text-color:orange;
            }
            
            
        }
        </style>
    </head>
    <body>

        <div class="form-signin-heading text-center" align="center">

            <div class="retour">
     
                    
                        <a href="profil.php" >
                            <div class="material-icons">keyboard_return </div>
                            Retour à la page précédente
                        </a>
         


                
            </div>
            
            <br>
            <br>
            <form method="post" class="form-signin" action ="feedback.php">
            


                <h2 class="titre">Vous nous avez connu comment?</h2>
                <br>
                <span class="mon_texte"><p>Chers utilisateurs,<p>
                merci de nous dire comment vous nous avez connu, cela facilitera nos prochaines campagnes de communication.
                </span>
                <br>
                <br>
                <fieldset>

                    <legend>Sondage</legend>

                    <p>Comment vous nous avez connu?</p>
                   
                    <ul>

                        <li><input type="checkbox" name="ch[]" value="Supinfo" <?php if(@in_array("Supinfo",$ch)) echo "checked";?> />Supinfo</li><br>
                        
                        <li><input type="checkbox" name="ch[]" value="Moteur de recherche" <?php if(@in_array("Moteur de recherche",$ch)) echo "checked";?> />Moteur de recherche</li><br>
                        <li><input type="checkbox" name="ch[]" value="Ancien adherents, reinscription" <?php if(@in_array("Ancien adherents, reinscription",$ch)) echo "checked";?> />Ancien adhérents, réinscription</li><br>
                        <li><input type="checkbox" name="ch[]" value="Bouches a oreilles" <?php if(@in_array("Bouches a oreilles",$ch)) echo "checked";?> />Bouches à oreilles</li><br>
                        <li><input type="checkbox" name="ch[]" value="Flyer dans votre boite aux lettres" <?php if(@in_array("Flyer dans votre boite aux lettres",$ch)) echo "checked";?> />Flyer dans votre boite aux lettres</li><br>
                        <li><input type="checkbox" name="ch[]" value="Facebook" <?php if(@in_array("Facebook",$ch)) echo "checked";?> />Facebook</li><br>
                        <li><input type="checkbox" name="ch[]" value="Reseaux Sociaux" <?php if(@in_array("Reseaux Sociaux",$ch)) echo "checked";?> />Réseaux Sociaux</li><br>
                        <li><input type="checkbox" name="ch[]" value="Autre reponse" <?php if(@in_array("Autre reponse",$ch)) echo "checked";?> />Autre réponse</li><br>
                    </ul>

                    <p>Etes-vous satisfait de notre application web?</p>
               
                    <input type="radio" name="compteutilisateur" value="oui">Oui</input><br>
                    <input type="radio" name="compteutilisateur" value="non">Non</input>

                    <p>Que pensez vous de notre outil de sondage?</p>
                    
                    <textarea placeholder="Entrer du texte..." name="description" rows="5" cols="33">
                    
                    </textarea>
                    <br>

                </fieldset>

                <input type="submit" class="bouton_soumettre" name="soumission" value="Soumettre"/>

            </form>
            
            
        </div>

        <div class="speed-dial">
            <button class="speed-dial__button speed-dial__button--primary">
                <i class="material-icons">menu</i>
            </button>
            <div class="speed-dial__options">



                <a href="deconnexion.php" class="speed-dial__button">
                    <div class="material-icons">power_settings_new</div>
                        
                </a>

                <a href="editionprofil.php" class="speed-dial__button">
                    <div class="material-icons">edit</div>
                </a>
                    
                <a href="feedback.php" class="speed-dial__button">
                    <div class="material-icons">rule</div>
                        
                </a>

                <a href="brouillon.php" class="speed-dial__button">
                    <div class="material-icons">note_add</div>
                </a>

                <a href="sondageanalyse.php" class="speed-dial__button">
                    <div class="material-icons">show_chart</div>
                        
                </a>

                <a href="profil.php" class="speed-dial__button">
                    <div class="material-icons">home</div>
                        
                </a>

            </div>

        </div>

        
        <script src="js/mainprofil.js"></script>


    </body>

</html>