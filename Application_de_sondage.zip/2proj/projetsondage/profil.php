<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";

try {
    $bdd = new PDO("mysql:host=$servername;dbname=fin_annee_projet", $username, $password);
    // set the PDO error mode to exception
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }

if(isset($_SESSION['id']) AND $_SESSION['id']>0){

    $getid = intval($_SESSION['id']);
    $requser=$bdd->prepare("SELECT * FROM membres WHERE id = ? ");
    $requser->execute(array($getid));
    $userinfo = $requser->fetch();
    
?>
   

<html>

    <head>
        <title>Profil</title>
        <meta charset ="utf-8"/>
        <link rel="stylesheet" type="text/css" href="css/styleprofil.css">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        
    </head>
    <body>
        <header class="header">

            <div class="inner_header">

                <ul>

                    <li><img src="img/logo.png" alt="logo"></li>
                    <li id="btn_send"><input type="submit" class="bouton" value="Envoyer" /></li>
                   
                </ul> 
                
            </div>
            
        </header>
        

        <br>
        <br>
        

        <div align="center">

            <h2>Bienvenue <?php echo $userinfo['pseudo']; ?> !</h2>
            <br>
            
        </div>
    
        <center>
        <nav>
            <ul>
                <li><a href="profil.php">Questions</a></li>
                <li><a href="#">Réponses</a></li>

            </ul>

        </nav>
        </center>
        <br>
        <br>
        <center>
        <div class="title_survey">

            <input type="text" name="title" autocomplete="off" required>
           
            <label for="title" class="label-title">
                <span class="content-title"><b>Titre du questionnaire</b></span>
            </label>

        </div>

        </center>

        <br>
        <center>
        <div class="question">
            <ul class="type_reponse">
                <li><input text="text" placeholder="Question sans titre" class="intitule"/></li>
                <li><select class="selection" name="type_reponse">

                    <option value="reponse simple">reponse courte</option>
                    <option value="reponse longue">reponse longue</option>
                    <option value="reponse multiple">reponse multiple</option>
                    <option value="reponseacocher">case à cocher</option>
                    <option value="reponse numerique">reponse numerique</option>
                    <option value="reponse date">date</option>
                    <option value="reponse temps">temps</option>
                        
                </select></li>
            </ul>


            <div class="reponseinput">
                <table>
                    <tr>
                        <td>
                            <span id="label1"><i class="far fa-circle"></i> </span>
                            <input type="text" value="" id="input1"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <span id="label2"><i class="far fa-circle"></i> </span>
                            <input type="text" value="" id="input2" />
                        </td>
                    </tr>
                </table>            
            </div>     
  
        </div>

        
        </center>
       





        <?php

        include("menus.php");

        ?>
        <footer>

            <div class="footer-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 col-sm-6 col-xs-12 segment-one">
                            <h3>Aide</h3>
                            <p>Veuillez nous écrire un mail en cas de problème</p>
                            
                            <a class="mail" href="mailto:paulyoumbi214@gmail.com">Nous envoyez un mail</a>
                            
                        </div>
                        
                        <div class="col-md-3 col-sm-6 col-xs-12 segment-three">
                            <h2>Partenaires</h2>
                            <ul>
                                <li><a href="#"></a>Etablissement</li>
                    
                            </ul>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-12 segment-four">
                        
                            <h2> Notre Newletter</h2>
                            
                            <form action="">
                                <input type="email">
                                <input type="submit" value="s'abonner">
                            </form>
                            
                            
                        </div>
                    </div>
                    
                </div>
                <br>
                <br>
                <p>&copy; 2020 online survey. Tous droits reservés.</p>
            </div>
		
           

			
	
		
		
	    </footer>	





        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

        <script src="js/mainprofil.js"></script>
        <script src="https://kit.fontawesome.com/a81368914c.js"></script>
        
        <script type="text/javascript">
            
            $(document).ready(function() {
                
                $("option[value='reponse multiple']").click(function() {

                
                    
                   
                    $("#label1").html("<i class="far fa-circle"></i>");
                    
                });

                $("option[value='reponse longue']").click(function() {
                    $("#input1").attr("type", "text");
                    $("#input1").attr("maxlength", 255);
                   
                });

                $("option[value='reponse simple']").click(function() {
                    
                    
                    $(".rcourte").show(); 

                });

                $("option[value='reponseacocher']").click(function() {
                  
                    $("#label1").html();
                    $("#label1").html("<i class="far fa-square"></i>");
                });

                $("option[value='reponse numerique']").click(function() {
                    $("#input1").attr("type", "number");
                   

                });

                $("option[value='reponse date']").click(function() {
                    $("#input1").attr("type", "date");
                   
                    
                });

                $("option[value='reponse temps']").click(function() {
                    $("#input1").attr("type", "time");
                   
                    
                });


            });
            
        </script>

    </body>
</html>

<?php

}

?>


   
