<html>
    <head>

    </head>

    <body>

        <div class="speed-dial">
            <button class="speed-dial__button speed-dial__button--primary">
                <i class="material-icons">menu</i>
            </button>
            <div class="speed-dial__options">

                <a href="deconnexion.php" class="speed-dial__button">
                    <div class="material-icons">power_settings_new</div>
                        
                </a>

                <a href="editionprofil.php" class="speed-dial__button">
                    <div class="material-icons">edit</div>
                </a>
                    
                <a href="feedback.php" class="speed-dial__button">
                    <div class="material-icons">rule</div>
                        
                </a>

                <a href="brouillon.php" class="speed-dial__button">
                    <div class="material-icons">note_add</div>
                </a>

                <a href="profil.php" class="speed-dial__button">
                    <div class="material-icons">home</div>
                        
                </a>

            </div>

        </div>


        

    </body>

</html>