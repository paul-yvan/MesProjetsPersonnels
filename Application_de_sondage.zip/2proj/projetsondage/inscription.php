<?php
$servername = "localhost";
$username = "root";
$password = "";

try {
    $bdd = new PDO("mysql:host=$servername;dbname=fin_annee_projet", $username, $password);
    // set the PDO error mode to exception
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
?> 
<?php

    if(isset($_POST['forminscription'])){

        $pseudo = htmlspecialchars($_POST['pseudo']);
        $mail = htmlspecialchars($_POST['mail']);
        $mdp = sha1($_POST['mdp']);
        $mdp2 = sha1($_POST['mdp2']);


        if(!empty($_POST['pseudo']) AND !empty($_POST['mail']) AND !empty($_POST['mdp']) AND !empty($_POST['mdp2'])){

            $reqpseudo = $bdd->prepare("SELECT * FROM membres WHERE pseudo = ?");
            $reqpseudo->execute(array($pseudo));
            $pseudoexist = $reqpseudo->rowCount();

            if($pseudoexist == 0){

                $pseudolength = strlen($pseudo);

                if($pseudolength <= 255){


                    

                     if(filter_var($mail, FILTER_VALIDATE_EMAIL)){

                        $reqmail = $bdd->prepare("SELECT * FROM membres WHERE mail = ?");
                        $reqmail->execute(array($mail));
                        $mailexist = $reqmail->rowCount();
                        if($mailexist == 0){           
                            if($mdp == $mdp2){

                                $sql=$bdd->prepare("INSERT INTO membres(pseudo, mail, motdepasse) VALUES (?, ?, ?)");
                                $sql->execute(array($pseudo,$mail,$mdp));

                                $erreur = "Votre compte a bien été créé !";

                            }else{

                                $erreur = "Vos mots de passe ne correspondent pas!";

                            }
                        }else{

                            $erreur = "Adresse mail deja utilisée !";
                                
                        }
                    }else{

                        $erreur = "Votre adresse mail n'est pas valide!";

                    }
                    

                }else{

                    $erreur = "votre pseudo ne doit pas depasser 255 caractères";

                }
            }else{

                $erreur = "Ce pseudo existe deja !";

            }
        } else{

            $erreur = "Tous les champs doivent etre complétés!";
    
        }

    
    }

?>

<html>

    <head>
        <title>Page d'inscription</title>
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/a81368914c.js"></script>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <meta charset="utf-8"/>
    </head>

    <body>

        <img class="wave" src="img/wave.png">

        <div class="retour">
            <div class="speed-dial">
                
                <div class="speed-dial__options">
                   
                    <a href="index.php" class="speed-dial__button">
                        <div class="material-icons">keyboard_return </div>
                        Retour à la page précédente
                    </a>
                </div>

            </div>


             
        </div>

        <div class="container">

            <div class="img">
                <img src="img/bg.svg">
            </div>

            <div class="login-content">

                <form method="post"action="">
                
                    <h2 class="title">Inscription</h2>

                    <div class="input-div one">

                        <div class="i">
                                <i class="fas fa-user"></i>
                        </div>

                        <div class="div">
                            <h5>Pseudo</h5>
                            <input type="text" class="input" id="pseudo" name="pseudo" value ="<?php  if(isset($pseudo)){ echo $pseudo; } ?>" />
                        </div>
                    
                        <div class="i">
                            <i class="fas fa-envelope"></i>
                        </div>

                        <div class="div">
                            <h5>Email</h5>
                            <input type="email" class="input" id="mail" name="mail"  value ="<?php  if(isset($mail)){ echo $mail; } ?>" />
                        </div>

                    </div>

                    <div class="input-div pass">

                        <div class="i"> 
                            <i class="fas fa-lock"></i>
                        </div>

                        <div class="div">
                            <h5>Mot de passe</h5>
                            <input type="password" class="input" id="mdp" name="mdp"/>
                        </div>

                        <div class="i"> 
                                <i class="fas fa-lock"></i>
                        </div>

                        <div class="div">
                            <h5>Confirmation du mot de passe</h5>
                            <input type="password" class="input" id="mdp2" name="mdp2" />
                        </div>

                    </div>
        
                    <input type="submit" class="btn" value="Nous rejoindre!" name="forminscription" />
                    
                    <?php
                        if(isset($erreur)){

                            echo $erreur;

                        }
                    ?>


                </form>
            </div>

        </div>

        <script type="text/javascript" src="js/main.js"></script>
        
    </body>

</html>