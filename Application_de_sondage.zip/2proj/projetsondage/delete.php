<?php
session_start();


$servername = "localhost";
$username = "root";
$password = "";


try {
    $bdd = new PDO("mysql:host=$servername;dbname=fin_annee_projet", $username, $password);
    // set the PDO error mode to exception
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }

if(!isset($_GET['id'])) {
    header("Location: ./brouillon.php");
}
$id = $_GET['id'];

if($_SERVER['REQUEST_METHOD'] == 'POST') {

    $sql=$bdd->prepare("DELETE FROM listes WHERE id = ? LIMIT 1");
    $sql->execute(array($id));

    // For DELETE statements, $result is true/false
    if($sql) {
        header("Location: ./brouillon.php?id=" . $id);
        return true;
    } else {
        // DELETE failed
        $bdd = NULL;
        return false;
    }

} else {
    $sql=$bdd->prepare("SELECT * FROM listes WHERE id = ?");
    $sql->execute(array($id));
    $liste=$sql->fetch();

}

?>
<html>
    <head>
        <title>Supprimer la question</title>
        <link rel="stylesheet" type="text/css" href="css/css/bootstrap.min.css"> 
        <link href="https://fonts.googleapis.com/css?family=Poppins:500&display=swap" rel="stylesheet">     
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <meta charset = "utf-8"/>
        <style type="text/css">
        body{
            background:#eee;
            font-family: 'Poppins', sans-serif;
        }
        :root{
            --bg-color:white;
            --text-color:rgb(41, 41, 41);
        }
        body{
                background-color: var(--bg-color);
                color: var(--text-color);
            }
        .wrapper{
            margin: 80px;
        }
        
        .btn{
            width:200px;
        }
        
        .back{
            margin-top:30px;
            margin-left:50px;
            
        }

        .form-signin{
            max-width:380px;
            margin: 0 auto;
            background-color:#fff;
            padding:15px 40px 50px;
            border:1px solid #e5e5e5;
            border-radius:10px;
        }
     

        a{
            display: block;
            text-align: right;
            text-decoration: none;
            color: #999;
            font-size: 0.9rem;
            transition: .3s;
        }

        a:hover{
            color: #38d39f;
            text-decoration:none;
        }

        .retour a{

            text-align:left;
            margin-top:50px;
            margin-left:50px;

        }

        .speed-dial{
            position:fixed;
            bottom:15px;
            right:15px;
        }
        .speed-dial__options{
            position:absolute;
            bottom:100%;
            width:100%;
            text-align:center;
        }

        .speed-dial__button{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            padding:12px;
            margin-bottom:15px;
            background: #cccccc;
            color: #333333;
            border-radius:50%;
            box-shadow:1px 1px 2px rgba(0,0,0,0.5);
            cursor:pointer;
            text-decoration:none;
            -webkit-tap-highlight-color:transparent;
            border:none;
            outline:none;
            transition: background 0.2s, opacity 0.2s, transform 0.2s; 

        }

        .speed-dial__button:active{
            background: #aaaaaa;
        }

        .speed-dial__button--primary{
            margin-bottom:0;
            padding:18px;
            background:#38d39f;
            color:#ffffff;
        }

        .speed-dial__button--primary:active{
            background:rgba(44, 1, 124, 0.986);
        }

        .speed-dial__button:not(.speed-dial__button--primary){
            opacity:0;
            transform:translateY(40px);
            visibility:hidden;
        }
        .speed-dial--active .speed-dial__button{
            opacity:1;
            transform:translateY(0);
            visibility:visible;
        }

        @media(prefers-color-scheme: dark){
            :root{
                --bg-color:rgb(41, 41, 41);
                --text-color:orange;
            }
            
            
        }
        </style>
    </head>
    <body>

        <div id="content">

            <div class="retour">
  
                            
                        <a href="brouillon.php">
                            <div class="material-icons">keyboard_return </div>
                            Retour à la page précédente
                        </a>
              

                    
            </div>

            <div class="wrapper" align="center">
                <h2 class="form-signin-heading text-center">Supprimer la question</h2>
                <br>

 
                <form class="form-signin" style="background-color:D3CBD8" action="" method="post">

                    <p><h5>Etes-vous sure de vouloir supprimer cette question?</h5></p>
                    <p class="item"><strong><< <?php echo $liste['menu_name']; ?> >></strong></p>

                    <div id="operations">
                        <button class="btn btn-lg btn-danger btn-block">Supprimer</button>
                    </div>

                </form>
            </div>

        </div>

        <?php

            include("menus.php");
        ?>
        
        <script src="js/mainprofil.js"></script>
    
    </body>

</html>

