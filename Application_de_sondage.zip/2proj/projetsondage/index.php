<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";

try {
    $bdd = new PDO("mysql:host=$servername;dbname=fin_annee_projet", $username, $password);
    // set the PDO error mode to exception
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }

if(isset($_POST['formconnexion'])){

    $pseudoconnect = htmlspecialchars($_POST['pseudoconnect']);
    $mdpconnect = sha1($_POST['mdpconnect']);
    if(!empty($pseudoconnect) AND !empty($mdpconnect)){

        $requser = $bdd->prepare("SELECT * FROM membres WHERE pseudo = ? AND motdepasse = ? ");
        $requser->execute(array($pseudoconnect,$mdpconnect));
        $userexist = $requser->rowCount();

        if($userexist == 1){

            $userinfo = $requser->fetch();
            $_SESSION['id'] = $userinfo['id'];
            $_SESSION['pseudo'] = $userinfo['pseudo'];
            $_SESSION['mail'] = $userinfo['mail'];
            header("Location:profil.php");

        }else{

            $erreur = "Cet utilisateur n'existe pas !";

        }


    }else{

        $erreur = "Tous les champs doivent etre complétés !";

    }
}

?> 


<html>

	<head>
		<title>Page de Login</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
		<script src="https://kit.fontawesome.com/a81368914c.js"></script>
		<meta charset="utf-8"/>
	</head>

	<body>

		<img class="wave" src="img/wave.png">

		<div class="inscription">
			<img src="img/logo.png">
			<a href="inscription.php">vous &ecirc;tes nouveau ?</a>
		</div>

		<div class="container">

			<div class="img">
				<img src="img/bg.svg">
			</div>

			<div class="login-content">

				<form method="post" action="">
				
					<img src="img/avatar.svg">

					<h2 class="title">Bienvenue</h2>

					<div class="input-div one">

						<div class="i">
							<i class="fas fa-user"></i>
						</div>
						
						<div class="div">

							<h5>Pseudo</h5>
							<input type="text" name="pseudoconnect" class="input" id="pseudo" value ="<?php  if(isset($pseudo)){ echo $pseudo; } ?>" />
						
						</div>
						
					</div>
					
					<div class="input-div pass">

						<div class="i"> 
							<i class="fas fa-lock"></i>
						</div>
							
						<div class="div">

							<h5>Mot de passe</h5>
							<input type="password" id="mdp" name="mdpconnect" class="input" />
						
						</div>

					</div>
					
					<a href="#">Mot de passe oublié?</a>
					
					<input type="submit" class="btn" name="formconnexion" value="Se connecter" />

					<?php
			
						if(isset($erreur)){

							echo $erreur;

						}
					?>
			
					
				</form>
				
			</div>

			
		</div>
		
		<script type="text/javascript" src="js/main.js"></script>
		
	</body>

</html>