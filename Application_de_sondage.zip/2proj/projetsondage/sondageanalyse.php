<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";

try {
    $bdd = new PDO("mysql:host=$servername;dbname=fin_annee_projet", $username, $password);
    // set the PDO error mode to exception
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }

$req=$bdd->prepare("SELECT * FROM reponse WHERE intitule = ? ");
$req->execute(array("Flyer dans votre boite aux lettres"));
$fdvbal=$req->rowCount();


$ref=$bdd->prepare("SELECT * FROM reponse WHERE intitule = ? ");
$ref->execute(array("Facebook"));
$f=$ref->rowCount();


$rer=$bdd->prepare("SELECT * FROM reponse WHERE intitule = ? ");
$rer->execute(array("Reseaux Sociaux"));
$rs=$rer->rowCount();


$rea=$bdd->prepare("SELECT * FROM reponse WHERE intitule = ? ");
$rea->execute(array("Ancien adherents, reinscription"));
$aar=$rea->rowCount();


$rem=$bdd->prepare("SELECT * FROM reponse WHERE intitule = ? ");
$rem->execute(array("Moteur de recherche"));
$mdr=$rem->rowCount();


$res=$bdd->prepare("SELECT * FROM reponse WHERE intitule = ? ");
$res->execute(array("Supinfo"));
$sup = $res->rowCount();


$rear=$bdd->prepare("SELECT * FROM reponse WHERE intitule = ? ");
$rear->execute(array("Autre reponse"));
$ar = $rear->rowCount();



$reo=$bdd->prepare("SELECT * FROM reponse WHERE intitule = ? ");
$reo->execute(array("oui"));
$o = $reo->rowCount();



$ren=$bdd->prepare("SELECT * FROM reponse WHERE intitule = ? ");
$ren->execute(array("non"));
$n = $ren->rowCount();



?>
<html>
  <head>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Poppins:500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/css/bootstrap.min.css"> 
    <meta charset = "utf-8"/>
    <style type="text/css">
        body{

               
                font-family: 'Poppins', sans-serif;
            }

        a{
            display: block;
            text-align: right;
            text-decoration: none;
            color: #999;
            font-size: 0.9rem;
            transition: .3s;
        }

        a:hover{
            color: #38d39f;
            text-decoration:none;
        }

        .retour a{

            text-align:left;
            margin-top:50px;
            margin-left:50px;

        }
        .speed-dial{
            position:fixed;
            bottom:15px;
            right:15px;
        }
        .speed-dial__options{
            position:absolute;
            bottom:100%;
            width:100%;
            text-align:center;
        }

        .speed-dial__button{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            padding:12px;
            margin-bottom:15px;
            background: #cccccc;
            color: #333333;
            border-radius:50%;
            box-shadow:1px 1px 2px rgba(0,0,0,0.5);
            cursor:pointer;
            text-decoration:none;
            -webkit-tap-highlight-color:transparent;
            border:none;
            outline:none;
            transition: background 0.2s, opacity 0.2s, transform 0.2s; 

        }

        .speed-dial__button:active{
            background: #aaaaaa;
        }

        .speed-dial__button--primary{
            margin-bottom:0;
            padding:18px;
            background:#38d39f;
            color:#ffffff;
        }

        .speed-dial__button--primary:active{
            background:rgba(44, 1, 124, 0.986);
        }

        .speed-dial__button:not(.speed-dial__button--primary){
            opacity:0;
            transform:translateY(40px);
            visibility:hidden;
        }
        .speed-dial--active .speed-dial__button{
            opacity:1;
            transform:translateY(0);
            visibility:visible;
        }
        p{
            width:50%;
            text-align:justify;
        }


    </style>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load("current", {packages:["corechart"]});
        google.charts.setOnLoadCallback(drawChart);


        function drawChart() {
        var data = google.visualization.arrayToDataTable([
            ['Task', 'Hours per Day'],
            ['Supinfo', <?php echo $sup; ?>],
            ['Moteur de recherche', <?php echo $mdr; ?>],
            ['Ancien adhérents, réinscription', <?php echo $aar; ?>],
            ['Flyer dans votre boite aux lettres',<?php echo $fdvbal; ?>],
            ['Facebook', <?php echo $f; ?>],
            ['Réseaux Sociaux', <?php echo $rs; ?>],
            ['Autre réponse', <?php echo $ar; ?>]
        ]);

        var options = {
          title: 'Comment vous nous avez connu?',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }



    </script>

    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Oui', <?php echo $o; ?>],
          ['Non', <?php echo $n; ?>],
        
        ]);

        var options = {
          title: 'Etes-vous satisfait de notre application web?',
          pieHole: 0.4,
        };

        var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
        chart.draw(data, options);
      }
    </script>

  </head>
  <body>
    
    <div class="retour">
                        
        <a href="feedback.php" >
            <div class="material-icons">keyboard_return </div>
            Retour à la page précédente
        </a>

    </div>
    <center>
    <br>
    <h2 style="color:433f99">Statistiques</h2>
    <br>
    <p>
    Chers utilisateurs,<br><br>
    ces diagrammes représentent le recapitulatif en version graphique des différentes réponses obtenues de ce questionnaire.
    </p>
   
    <div id="piechart_3d" style="width: 900px; height: 500px;"></div>
    <br>
    <div id="donutchart" style="width: 900px; height: 500px;"></div>

    </center>

    <?php

        include("menus.php");
    ?>
        
    <script src="js/mainprofil.js"></script>
    
  </body>
</html>
