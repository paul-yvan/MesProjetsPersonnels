<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$i = 0;

$statuts = [
    0 => 'Question en cours de traitement',
    1 => 'Question définitive'
];

try {
    $bdd = new PDO("mysql:host=$servername;dbname=fin_annee_projet", $username, $password);
    // set the PDO error mode to exception
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }

if(isset($_SESSION['id']) AND $_SESSION['id']>0){

    $getid = intval($_SESSION['id']);
    $requser=$bdd->prepare("SELECT * FROM membres WHERE id = ? ");
    $requser->execute(array($getid));
    $userinfo = $requser->fetch();
 
    // On eécupère la todolist de l'utilisateur
    $requser=$bdd->prepare("SELECT * FROM listes WHERE membres_id = ? ");
    $requser->execute(array($getid));
    //$todolist = $requser->fetch();

    
?>
   

<html>

    <head>
        <title>Brouillon </title>
        <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/css?family=Poppins:500&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/css/bootstrap.min.css">      
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <meta charset = "utf-8"/>
        <style type="text/css">
        :root{
            --bg-color:white;
            --text-color:rgb(41, 41, 41);
        }
        body{
                background-color: var(--bg-color);
                color: var(--text-color);
                font-family: 'Poppins', sans-serif;
            }
        
        
        .menu{
            margin-top:30px;
            margin-right:50px;
        }

        a{
            display: block;
            text-align: right;
            text-decoration: none;
            color: #999;
            font-size: 0.9rem;
            transition: .3s;
        }

        a:hover{
            color: #38d39f;
            text-decoration:none;
        }

        .retour a{

            text-align:left;
            margin-top:50px;
            margin-left:50px;

        }
        
        .speed-dial{
            position:fixed;
            bottom:15px;
            right:15px;
        }
        .speed-dial__options{
            position:absolute;
            bottom:100%;
            width:100%;
            text-align:center;
        }

        .speed-dial__button{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            padding:12px;
            margin-bottom:15px;
            background: #cccccc;
            color: #333333;
            border-radius:50%;
            box-shadow:1px 1px 2px rgba(0,0,0,0.5);
            cursor:pointer;
            text-decoration:none;
            -webkit-tap-highlight-color:transparent;
            border:none;
            outline:none;
            transition: background 0.2s, opacity 0.2s, transform 0.2s; 

        }

        .speed-dial__button:active{
            background: #aaaaaa;
        }

        .speed-dial__button--primary{
            margin-bottom:0;
            padding:18px;
            background:#38d39f;
            color:#ffffff;
        }

        .speed-dial__button--primary:active{
            background:rgba(44, 1, 124, 0.986);
        }

        .speed-dial__button:not(.speed-dial__button--primary){
            opacity:0;
            transform:translateY(40px);
            visibility:hidden;
        }
        .speed-dial--active .speed-dial__button{
            opacity:1;
            transform:translateY(0);
            visibility:visible;
        }

        @media(prefers-color-scheme: dark){
            :root{
                --bg-color:rgb(41, 41, 41);
                --text-color:orange;
            }
            th{
                color:orange;
            }
            td{
                color:white;
            }
        }
        </style>
    </head>
    <body>
        <div class="retour">
             
                        
                  
                        
                        <a href="profil.php" >
                            <div class="material-icons">keyboard_return </div>
                              Retour à la page précédente
                        </a>
                    


                
        </div>
        

        <br>
        <br>
        

        <div align="center">

            <h2>Hey <?php echo $userinfo['pseudo']; ?>, ton brouillon n'attend que toi!</h2>
            <br>
            <h4>Mes questions préparées:</h4>
            <br>
        </div>
           

            <?php
            if(isset($_SESSION['id']) AND $userinfo['id'] == $_SESSION['id']){

               
            ?>
                
                <div class="container">
                    <a class="btn btn-secondary" href="nouveau.php">Ajouter une question</a>
                    <br>
                    <br>
                    <table border="1" class= "table table-striped table-bordered">
                        <tr>
                            
                            <th style="background-color:#32be8f"><span style="color:white">Position</span></th>
                            <th style="background-color:#32be8f"><span style="color:white">Intitulé</span></th>
                            <th style="background-color:#32be8f"><span style="color:white">statut</span></th>
                            <th style="background-color:#32be8f">&nbsp;</th>
                            <th style="background-color:#32be8f">&nbsp;</th>
                        
                            
                        </tr>

                        <?php while($liste = $requser->fetch()) { ?>
                            
                            <tr>
                            
                                <td><?php echo $i + 1; ?></td>
                                <td><?php echo $liste['menu_name']; ?></td>
                                <td><?php echo $statuts[$liste['status']] ; ?></td>
                                
                                <td align="center"><?php echo '<a class="action btn btn-success" href="editionquestion.php?id=' . $liste["id"] . '" >Edit</a>'?></td>
                                <td align="center"><?php echo '<a class="action btn btn-danger" href="delete.php?id='. $liste["id"] . '"  >Delete</a>'?></td>
                              
                            
                            </tr>

                            <?php $i += 1 ?>

                        <?php } ?>
                    </table>

                </div>
                
            <?php
            } 

            include("menus.php");
            ?>

            
        
    
        <script src="js/mainprofil.js"></script>
        

    </body>
</html>

<?php

}

?>

