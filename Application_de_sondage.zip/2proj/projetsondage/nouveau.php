<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";

$statuts = [
    0 => 'En cours de traitement',
    1 => 'Question définitive'
];

try {
    $bdd = new PDO("mysql:host=$servername;dbname=fin_annee_projet", $username, $password);
    // set the PDO error mode to exception
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }

    $getid = intval($_SESSION['id']);
    
if($_SERVER['REQUEST_METHOD'] == 'POST') {

    
    $liste = [];
    $liste['membres_id'] = $getid;
    $liste['menu_name'] = isset($_POST['menu_name']) ? $_POST['menu_name'] : '';
    $liste['position'] = isset($_POST['position']) ? $_POST['position'] : '';
    $liste['status'] = isset($_POST['status']) ? $_POST['status'] : '';
    

    $reqadd=$bdd->prepare("INSERT INTO listes (membres_id, menu_name, status, position) VALUES (?, ?, ?, ?) ");
    $reqadd->execute(array($liste['membres_id'], $liste['menu_name'], $liste['status'], 0));

	// For INSERT statements, $result is true/false
	if($reqadd) {
        header("Location: ./brouillon.php");
        return true;
        
	} else {
		// INSERT failed
        $bdd = NULL;
		exit;
	}
    


    $new_id = $bdd->lastInsertId(); 
    

} else {
  $liste = [];
  $liste = [];
  $liste['menu_name'] = '';
  $liste['position'] = '';
  $liste['status'] = '';
  

  $liste_set =$bdd->prepare("SELECT COUNT(*) FROM listes WHERE membres_id = ? ORDER BY position ASC");
  $liste_set->execute(array($getid));
  $liste_count = intval($liste_set->fetch()[0]) + 1;

}

?>

<html>  

    <head>
        <title>Nouvelle question</title>
        <link rel="stylesheet" type="text/css" href="css/css/bootstrap.min.css">     
        <link href="https://fonts.googleapis.com/css?family=Poppins:500&display=swap" rel="stylesheet"> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <meta charset = "utf-8"/>
        <style type="text/css">
        body{
            background:#eee;
            font-family: 'Poppins', sans-serif;
        }
        :root{
            --bg-color:white;
            --text-color:rgb(41, 41, 41);
        }
        body{
                background-color: var(--bg-color);
                color: var(--text-color);
            }
        .wrapper{
            margin: 80px;
        }
        .form-signin{
            max-width:380px;
            margin: 0 auto;
            background-color:#fff;
            padding:15px 40px 50px;
            border:1px solid #e5e5e5;
            border-radius:10px;
        }
        .form-signin input[type="text"]{
            margin-bottom:20px;
        }
        .form-signin .form-control{
            padding:10px;
        }
        
        .back{
            margin-top:30px;
            margin-left:50px;
            
        }

        a{
            display: block;
            text-align: right;
            text-decoration: none;
            color: #999;
            font-size: 0.9rem;
            transition: .3s;
        }

        a:hover{
            color: #38d39f;
            text-decoration:none;
        }

        .retour a{

            text-align:left;
            margin-top:50px;
            margin-left:50px;

        }

        .speed-dial{
            position:fixed;
            bottom:15px;
            right:15px;
        }
        .speed-dial__options{
            position:absolute;
            bottom:100%;
            width:100%;
            text-align:center;
        }

        .speed-dial__button{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            padding:12px;
            margin-bottom:15px;
            background: #cccccc;
            color: #333333;
            border-radius:50%;
            box-shadow:1px 1px 2px rgba(0,0,0,0.5);
            cursor:pointer;
            text-decoration:none;
            -webkit-tap-highlight-color:transparent;
            border:none;
            outline:none;
            transition: background 0.2s, opacity 0.2s, transform 0.2s; 

        }

        .speed-dial__button:active{
            background: #aaaaaa;
        }

        .speed-dial__button--primary{
            margin-bottom:0;
            padding:18px;
            background:#38d39f;
            color:#ffffff;
        }

        .speed-dial__button--primary:active{
            background:rgba(44, 1, 124, 0.986);
        }

        .speed-dial__button:not(.speed-dial__button--primary){
            opacity:0;
            transform:translateY(40px);
            visibility:hidden;
        }
        .speed-dial--active .speed-dial__button{
            opacity:1;
            transform:translateY(0);
            visibility:visible;
        }


        @media(prefers-color-scheme: dark){
            :root{
                --bg-color:rgb(41, 41, 41);
                --text-color:orange;
            }
            
            
        }
        </style>
    </head>
    <body>

        <div id="content">
            <div class="retour">
                
                        
                        <a href="brouillon.php">
                            <div class="material-icons">keyboard_return </div>
                              Retour à la page précédente
                        </a>
               


                
            </div>

            <div class="wrapper" align="center">
                <h2 class="form-signin-heading text-center">Ajouter une question</h2>
                <br>
                <form action="nouveau.php" style="background-color:D3CBD8" class="form-signin" method="post">
                    
                    <dt >intitulé de la question</dt>
                    <dd><input type="text" class="form-control" placeholder="intitulé de la question..." name="menu_name" value="<?php $liste['menu_name']; ?>" /></dd>
                    </dl>
                    
                    <dl>
                    <dt >Statut</dt>
                    <dd>
                        <input type="hidden" name="status" value="0" />
                        <input type="checkbox"  name="status" value="1"<?php echo " checked";  ?> />
                    </dd>
                    </dl>
                    
                    <div id="operations">
                        <button class="btn btn-lg btn-success btn-block">Créer la question </button>
                    </div>
                </form>
            </div>
        </div>
        <?php

            include("menus.php");
        ?>
        
        <script src="js/mainprofil.js"></script>

    </body>

</html>




