-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  Dim 14 juin 2020 à 14:45
-- Version du serveur :  10.4.10-MariaDB
-- Version de PHP :  5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `fin_annee_projet`
--

-- --------------------------------------------------------

--
-- Structure de la table `listes`
--

DROP TABLE IF EXISTS `listes`;
CREATE TABLE IF NOT EXISTS `listes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `membres_id` int(11) NOT NULL,
  `menu_name` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `membres_id` (`membres_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `listes`
--

INSERT INTO `listes` (`id`, `membres_id`, `menu_name`, `status`, `position`) VALUES
(1, 6, 'quel est ton age', '1', 0),
(7, 5, 'tu fais quoi demain?', '1', 0),
(10, 7, 'how old are you?', '1', 0);

-- --------------------------------------------------------

--
-- Structure de la table `membres`
--

DROP TABLE IF EXISTS `membres`;
CREATE TABLE IF NOT EXISTS `membres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `motdepasse` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `membres`
--

INSERT INTO `membres` (`id`, `pseudo`, `mail`, `motdepasse`) VALUES
(4, 'dylane', 'dylane@gmail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220'),
(3, 'sacha', 'sacha@gmail.com', '1e02c9a5efa4ca779544c804401b487a4c0e7391'),
(5, 'Paul-yvan', 'paulyvan@gmail.com', '22390ad11c32faec43fc61555b53607660b3c185'),
(6, 'sharky', 'sharky@gmail.com', '62757b706afb7aa34efbbf3cec0130313fc93778'),
(7, 'alain', 'alainbeaumarchet@yahoo.fr', '7c5ada740839a40059abebf8ffa27b68f89ccb2c');

-- --------------------------------------------------------

--
-- Structure de la table `question`
--

DROP TABLE IF EXISTS `question`;
CREATE TABLE IF NOT EXISTS `question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `questionnaire_id` int(11) NOT NULL,
  `intitule` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `statut` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `questionnaire_id` (`questionnaire_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `questionnaire`
--

DROP TABLE IF EXISTS `questionnaire`;
CREATE TABLE IF NOT EXISTS `questionnaire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `nbre_question` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reponse`
--

DROP TABLE IF EXISTS `reponse`;
CREATE TABLE IF NOT EXISTS `reponse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `intitule` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `question_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `question_id` (`question_id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `reponse`
--

INSERT INTO `reponse` (`id`, `intitule`, `type`, `question_id`) VALUES
(1, 'Autre reponse', '', 0),
(2, 'oui', '', 0),
(3, '                    \r\n                    ', '', 0),
(4, 'Supinfo', '', 0),
(5, 'Moteur de recherche', '', 0),
(6, 'Ancien adherents, reinscription', '', 0),
(7, 'Bouches a oreilles', '', 0),
(8, 'Flyer dans votre boite aux lettres', '', 0),
(9, 'Facebook', '', 0),
(10, 'Reseaux Sociaux', '', 0),
(11, 'Autre reponse', '', 0),
(12, '                    \r\n                    ', '', 0),
(13, 'Supinfo', '', 0),
(14, 'Autre reponse', '', 0),
(15, '                    \r\n                    ', '', 0),
(16, 'non', '', 0),
(17, '                    \r\n                    ', '', 0),
(18, 'oui', '', 0),
(19, '                    \r\n                    ', '', 0),
(20, 'Supinfo', '', 0),
(21, 'Moteur de recherche', '', 0),
(22, 'Ancien adherents, reinscription', '', 0),
(23, 'oui', '', 0),
(24, '                    \r\n                    ', '', 0),
(25, 'Supinfo', '', 0),
(26, 'Moteur de recherche', '', 0),
(27, 'non', '', 0),
(28, '                    \r\n                    ', '', 0),
(29, 'Facebook', '', 0),
(30, 'Reseaux Sociaux', '', 0),
(31, 'oui', '', 0),
(32, 'Je suis un biggiss\r\n          \r\n                    ', '', 0),
(33, 'Supinfo', '', 0),
(34, 'Moteur de recherche', '', 0),
(35, 'Autre reponse', '', 0),
(36, 'oui', '', 0),
(37, '                    \r\n                    ', '', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
