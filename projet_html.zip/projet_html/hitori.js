$(document).ready(function() {
	$('#contenu_panneau').hide();
	$('.open').hover(function (){
		$(this).width(1.25*$(this).width());
		$(this).height(1.25*$(this).height());
	},function(){
		$(this).width(0.8*$(this).width());
		$(this).height(0.8*$(this).height());
		
		if($('#contenu_panneau').is(':visible')){Q
			$('#contenu_panneau').slideUp();
			$('.open').text('Règles');
		
		}else{
			$('#contenu_panneau').slideDown();
			$('.open').text('Règles');
		
			
		}
		return false;
	});
	
	$(".board1").click(function(){
		var tab0=[[5,4,4,3,4],[3,4,2,5,4],[2,5,5,1,2],[2,2,1,4,5],[4,1,5,3,2]];

		function refreshTable(){
			var html="";	
			for(var i=0;i<5;i++){
				html+="<tr>";
				for(var j=0;j<5;j++){
					html+="<td>"+tab0[i][j]+"</td>";
				}
			
				html+="</tr>";
			
			
			}
			$('#grille1').html(html);
		}
		refreshTable();
		$('#grille1').fadeIn(1000);
		$('#grille2').hide();
		$('#grille3').hide();
		$('#grille1').show();
		
		$('td').click(function(){
			$(this).css('backgroundColor','black');
			$(this).css('color','white');
			
		});	
		
	});
		
	
	$(".board2").click(function(){
		var tab0=[[4,4,4,2,2],[4,2,3,5,1],[1,1,2,5,4],[1,3,4,1,5],[3,5,4,4,1]];

		function Table2(){
		var html="";	
		for(var i=0;i<5;i++){
			html+="<tr>";
			for(var j=0;j<5;j++){
				html+="<td>"+tab0[i][j]+"</td>";
			}
		
			html+="</tr>";
		
		
			}
			
			$('#grille2').html(html);
		}
		$('#grille2').fadeIn(1000);
		$('#grille1').hide();
		$('#grille3').hide();
		$('#grille2').show();
			
		Table2();
		$('td').click(function(){
			$(this).css('backgroundColor','black');
			$(this).css('color','white');
		});	
	});
	
	$(".board3").click(function(){
		var tab0=[[2,2,2,5,1],[5,4,2,3,4],[5,1,4,5,2],[2,4,5,1,3],[3,5,1,1,4]];

		function Table3(){
		var html="";	
		for(var i=0;i<5;i++){
			html+="<tr>";
			for(var j=0;j<5;j++){
				html+="<td>"+tab0[i][j]+"</td>";
			}
		
			html+="</tr>";
		
		
			}
			
			$('#grille3').html(html);
		}
		$('#grille3').fadeIn(1000);
		$('#grille1').hide();
		$('#grille2').hide();
		$('#grille3').show();
			
		Table3();
		$('td').click(function(){
			$(this).css('backgroundColor','black');
			$(this).css('color','white');
		});	
	});
	var tab0=[[0,0,1,0,1],[0,1,0,0,0],[0,0,1,0,1],[1,0,0,0,0],[0,0,0,1,0]];

	function result1(){
		var html="";	
		for(var i=0;i<5;i++){
			html+="<tr>";
			for(var j=0;j<5;j++){
				html+="<td>"+tab0[i][j]+"</td>";
			}
		
			html+="</tr>";
		
		
		}
		$('#grille1').html(html);
	}
		
	
	
	
	var tab0=[[1,0,1,0,1],[0,0,0,0,0],[0,1,0,1,0],[1,0,0,0,0],[0,0,1,0,1]];

	function result2(){
	var html="";	
	for(var i=0;i<5;i++){
		html+="<tr>";
		for(var j=0;j<5;j++){
			html+="<td>"+tab0[i][j]+"</td>";
		}
	
		html+="</tr>";
	
	
		}
		$('#grille2').html(html);
		}
		
	var tab0=[[1,0,1,0,0],[0,0,0,0,1],[1,0,0,1,0],[0,1,0,0,0],[0,0,0,1,0]];

	function result3(){
	var html="";	
	for(var i=0;i<5;i++){
		html+="<tr>";
		for(var j=0;j<5;j++){
			html+="<td>"+tab0[i][j]+"</td>";
		}
	
		html+="</tr>";
	
	
		}
		$('#grille3').html(html);
		}
		
	
	var m=prompt("veuillez entrez votre nom: ");
	alert('Bienvenue '+m );
	
	$("#start").click(function(){
	var span=document.querySelector("span");
	var inter=setInterval(function(){
		var seconds=parseInt(span.textContent);
		span.textContent=++seconds;
	},1000);
	});
	var i,divise;
	i = 0;
	divise=100;
	function reset(){
		i=0;
		document.getElementById("timer_out").innerHTML=(i/divise);
		
		
	}
	
	$('#reset_timer').click(function(){

		reset();		
		$('#grille1').hide();
		$('#grille2').hide();
		$('#grille3').hide();
		
		var alea = "#grille" + Math.floor(Math.random() * 3 + 1);
		console.log(alea);
		
		$(alea).show();
	});
	$('#reset_bouton').click(function(){
		//refreshTable();
		$('#grille1').hide();
		$('#grille2').hide();
		$('#grille3').hide();
		
		var alea = "#grille" + Math.floor(Math.random() * 3 + 1);
		console.log(alea);
		
		$(alea).show();
	});
});
