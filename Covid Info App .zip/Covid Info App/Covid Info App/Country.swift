//
//  Country.swift
//  Covid Info App
//
//  Created by Student Supinfo on 30/03/2021.
//  Copyright © 2021 Paul Yvan TCHINDJI YOUMBI. All rights reserved.
//

import Foundation

import SwiftUI

struct Response : Codable{
    
    var Global: GlobalStats
    
    var Countries: [Result]
    
    
}

struct GlobalStats: Codable{
    
    let id =  UUID().uuidString
    let NewConfirmed: Int //"NewConfirmed": 100282,
    let TotalConfirmed: Int //"TotalConfirmed": 1162857,
    let NewDeaths: Int //"NewDeaths": 5658,
    let TotalDeaths:Int //"TotalDeaths": 63263,
    let NewRecovered:Int //"NewRecovered": 15405,
    let TotalRecovered:Int //"TotalRecovered": 230845
    let Date:String? //"Date": "2021-03-19T21:14:04.244Z"
    
    
    
}

struct Result: Codable{
    
    let id = UUID().uuidString
    var Country: String //"Country": "Belarus",
    var CountryCode: String? //"CountryCode": "BY",
    var Slug: String? //"Slug": "belarus",
    let NewConfirmed: Int //"NewConfirmed": 89,
    var TotalConfirmed: Int //"TotalConfirmed": 440,
    var NewDeaths: Int //"NewDeaths": 1,
    var TotalDeaths: Int //"TotalDeaths": 5,
    var NewRecovered: Int //"NewRecovered": 0,
    var TotalRecovered: Int //"TotalRecovered": 53,
    var Date: String? //"Date": "2020-04-05T06:37:00Z"

}

