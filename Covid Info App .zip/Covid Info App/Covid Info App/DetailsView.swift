//
//  DetailsView.swift
//  Covid Info App
//
//  Created by Student Supinfo on 30/03/2021.
//  Copyright © 2021 Paul Yvan TCHINDJI YOUMBI. All rights reserved.
//

import SwiftUI

struct DetailsView: View {
    
    
    let row: Result
    
    let width = (UIScreen.main.bounds.width/2)-20
    
    var body: some View {
        
        VStack{
            
            
            
            Text(row.Country)
                .font(.system(size: 30, weight: .bold, design: .rounded))
            
            
            
            Spacer()
            
            HStack{
                
                
                
                ZStack{
                    
                    RoundedRectangle(cornerRadius: 8).frame(width:self.width, height:self.width).foregroundColor(Color(#colorLiteral(red: 0.8980392157, green: 0.8980392157, blue: 0.8980392157, alpha: 1)))
                        .shadow(radius: 10).padding()
                    
                    VStack{
                        
                        
                        Text("Nouveaux")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundColor(.black)
                        
                        Text("cas confirmés")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundColor(.black)
                        
                        Text("\(row.NewConfirmed)")
                            .font(.system(size: 21, weight: .bold, design: .rounded))
                            .foregroundColor(Color(#colorLiteral(red: 0.07843137255, green: 0.1294117647, blue: 0.2392156863, alpha: 1)))
                        
                        
                        
                        Text("Total de")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundColor(.black)
                        
                        Text("cas confirmés")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundColor(.black)
                        
                        
                        Text("\(row.TotalConfirmed)")
                            .font(.system(size: 21, weight: .bold, design: .rounded))
                            .foregroundColor(.orange)
                        
                    }
                    
                }
                
                ZStack{
                    
                    RoundedRectangle(cornerRadius: 8).frame(width:self.width, height:self.width).foregroundColor(Color(#colorLiteral(red: 0.8980392157, green: 0.8980392157, blue: 0.8980392157, alpha: 1)))
                        .shadow(radius: 10)
                    
                    VStack{
                        
                        Text("Nouveaux")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundColor(.black)
                        
                        Text("cas de décès")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundColor(.black)
                        
                        
                        Text("\(row.NewDeaths)")
                            .font(.system(size: 21, weight: .bold, design: .rounded))
                            .foregroundColor(Color(#colorLiteral(red: 0.07843137255, green: 0.1294117647, blue: 0.2392156863, alpha: 1)))
                        
                        
                        Text("Total")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundColor(.black)
                        
                        Text("de décès")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundColor(.black)
                        
                        Text("\(row.TotalDeaths)")
                            .font(.system(size: 21, weight: .bold, design: .rounded))
                            .foregroundColor(.red)
                        
                    }
                    
                }.padding(.trailing, 20)
                
                
            }
            
            ZStack{
                
                RoundedRectangle(cornerRadius: 8).frame(width:self.width, height:self.width).foregroundColor(Color(#colorLiteral(red: 0.8980392157, green: 0.8980392157, blue: 0.8980392157, alpha: 1)))
                    .shadow(radius: 10).padding()
                
                VStack{
                    
                    
                    Text("Nouveaux")
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                        .foregroundColor(.black)
                    
                    
                    Text("cas de rémission")
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                        .foregroundColor(.black)
                    
                    
                    Text("\(row.NewRecovered)")
                        .font(.system(size: 21, weight: .bold, design: .rounded))
                        .foregroundColor(Color(#colorLiteral(red: 0.07843137255, green: 0.1294117647, blue: 0.2392156863, alpha: 1)))
                    
                    Text("Total des")
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                        .foregroundColor(.black)
                    
                    Text("cas de rémission")
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                        .foregroundColor(.black)
                    
                    
                    Text("\(row.TotalRecovered)")
                        .font(.system(size: 21, weight: .bold, design: .rounded))
                        .foregroundColor(.green)
                    
                    
                }
                
                
            }
            
            Spacer()
            
        }.background(LinearGradient(gradient: .init(colors:[.orange,  Color(#colorLiteral(red: 0.07843137255, green: 0.1294117647, blue: 0.2392156863, alpha: 1))] ), startPoint: .top, endPoint: .bottom).edgesIgnoringSafeArea( .all))
        
    }
    
}


struct DetailsView_Previews: PreviewProvider {
    static var previews: some View {
        /*@START_MENU_TOKEN@*/Text("Hello, World!")/*@END_MENU_TOKEN@*/
    }
}
