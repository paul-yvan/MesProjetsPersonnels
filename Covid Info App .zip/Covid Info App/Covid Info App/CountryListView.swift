//
//  CountryListView.swift
//  Covid Info App
//
//  Created by Student Supinfo on 30/03/2021.
//  Copyright © 2021 Paul Yvan TCHINDJI YOUMBI. All rights reserved.
//

import Foundation
import SwiftUI

struct CountryListView: View {
    
    
    
    @State var results = [Result]()
    
    @State var showFavoritesOnly = false
    
    
    var body: some View {
        
        VStack{
            
            
            
            List {
                
                
                
                ForEach(results, id: \.id){ i in
                    
                    NavigationLink(destination: DetailsView(row: i)) {
                        
                        HStack{
                            
                            Text(i.Country)
                                .font(.system(size: 19, design: .rounded))
                            
                            Spacer()
                            
                            Text("\(i.TotalRecovered)/\(i.TotalConfirmed)")
                                .foregroundColor(.orange)
                            
                            
                        }
                        
   
                        
                    }
                    
                    
                    
                }
                    
                    
                .onDelete(perform: { indexSet in
                    self.results.remove(atOffsets: indexSet)
                })
                    .onMove(perform: { indices, newOffset in
                        self.results.move(fromOffsets: indices, toOffset:newOffset)
                    })
                
            }
                
            .listStyle(GroupedListStyle())
            
            
            
            
        }.background(LinearGradient(gradient: .init(colors:[.orange,  Color(#colorLiteral(red: 0.07843137255, green: 0.1294117647, blue: 0.2392156863, alpha: 1))] ), startPoint: .top, endPoint: .bottom).edgesIgnoringSafeArea( .all))
            
            
            
            
            .onAppear(perform: loadData)
        
        
    }
    
    
    func loadData(){
        
        guard let url=URL(string: "https://api.covid19api.com/summary") else{
            print("Url non valide")
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        request.setValue("5cf9dfd5-3449-485e-b5ae-70a60e997864", forHTTPHeaderField: "X-Access-Token")
        
        URLSession.shared.dataTask(with: request){ data, response, error in
            if let data = data{
                
                if let decodedResponse = try? JSONDecoder().decode(Response.self, from: data){
                    
                    DispatchQueue.main.async {
                        
                        self.results = decodedResponse.Countries
                        
                    }
                    
                }
                
                return
                
            }
            
            print("Fetch failed: \(error?.localizedDescription ?? "Unknown error") ")
            
        }.resume()
        
        
    }
    
    
}


struct CountryListView_Previews: PreviewProvider {
    static var previews: some View {
        CountryListView()
        //            .previewLayout(.sizeThatFits)
    }
}

