//
//  InfoGlobal.swift
//  Covid Info App
//
//  Created by Student Supinfo on 30/03/2021.
//  Copyright © 2021 Paul Yvan TCHINDJI YOUMBI. All rights reserved.
//

import SwiftUI
import Foundation
import Combine

struct InfoGlobal: View {
    
    
    @State var resultats = [GlobalStats]()
    
    let width = (UIScreen.main.bounds.width/2)-20
    
    
    var body: some View {
        
        
        
        VStack {
            
            
            Spacer()
            
            HStack{
                
                Text("Covid 19")
                    .font(.system(size: 40, weight: .bold, design: .rounded))
                
                Image("virus")
                    
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 70, height:70)
                    .clipped()
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.white, lineWidth: 3))
                    .shadow(radius: 5)
                
            }.padding(.top, 10)
            
            
            Text("Récapitulatif à échelle mondiale")
                .font(.system(size: 20, design: .rounded))
                .foregroundColor(.gray)
            
            Spacer()
            
            HStack {
                
                ForEach(resultats, id: \.id){ i in
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 8).frame(width:self.width, height:self.width).foregroundColor(.orange)
                            .shadow(radius: 10)
                        
                        VStack{
                            
                            Image(systemName: "person.fill")
                                .foregroundColor(Color(#colorLiteral(red: 0.07843137255, green: 0.1294117647, blue: 0.2392156863, alpha: 1)))
                                .padding(.all, 10)
                                .background(Color.white)
                                .clipShape(Circle())
                            
                            Text("Nouveaux")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundColor(.black)
                            
                            Text("cas confirmés ")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundColor(.black)
                            
                            
                            Text("\(i.NewConfirmed)")
                                .font(.system(size: 21, weight: .bold, design: .rounded))
                                .foregroundColor(Color(#colorLiteral(red: 0.8980392157, green: 0.8980392157, blue: 0.8980392157, alpha: 1)))
                        }
                        
                        
                    }
                    
                    
                    
                }
                
                ForEach(resultats, id: \.id){ i in
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 8).frame(width:self.width, height:self.width).foregroundColor(Color(#colorLiteral(red: 0.07843137255, green: 0.1294117647, blue: 0.2392156863, alpha: 1)))
                            .shadow(radius: 10)
                        
                        VStack{
                            
                            Image(systemName: "person.3.fill")
                                .foregroundColor(.orange)
                                .padding(.all, 10)
                                .background(Color.white)
                                .clipShape(Circle())
                            
                            Text("  Total de  ")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundColor(Color(#colorLiteral(red: 0.8980392157, green: 0.8980392157, blue: 0.8980392157, alpha: 1)))
                            
                            Text(" cas confirmés ")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundColor(Color(#colorLiteral(red: 0.8980392157, green: 0.8980392157, blue: 0.8980392157, alpha: 1)))
                            
                            Text("\(i.TotalConfirmed)")
                                .font(.system(size: 21, weight: .bold, design: .rounded))
                                .foregroundColor(.red)
                            
                        }
                        
                        
                        
                    }
                    
                    
                    
                }
                
                
                
            }
            HStack {
                
                ForEach(resultats, id: \.id){ i in
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 8).frame(width:self.width, height:self.width).foregroundColor(Color(#colorLiteral(red: 0.07843137255, green: 0.1294117647, blue: 0.2392156863, alpha: 1)))
                            .shadow(radius: 10)
                        
                        VStack{
                            
                            Image(systemName: "person.fill")
                                .foregroundColor(.orange)
                                .padding(.all, 10)
                                .background(Color.white)
                                .clipShape(Circle())
                            
                            Text("Nouveaux")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundColor(Color(#colorLiteral(red: 0.8980392157, green: 0.8980392157, blue: 0.8980392157, alpha: 1)))
                            
                            Text("décès")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundColor(Color(#colorLiteral(red: 0.8980392157, green: 0.8980392157, blue: 0.8980392157, alpha: 1)))
                            
                            Text("\(i.NewDeaths)")
                                .font(.system(size: 21, weight: .bold, design: .rounded))
                                .foregroundColor(.orange)
                            
                            
                        }
                        
                        
                        
                    }
                    
                    
                    
                }
                
                ForEach(resultats, id: \.id){ i in
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 8).frame(width:self.width, height:self.width).foregroundColor(.orange)
                            .shadow(radius: 10)
                        
                        VStack{
                            
                            Image(systemName: "person.3.fill")
                                .foregroundColor(Color(#colorLiteral(red: 0.07843137255, green: 0.1294117647, blue: 0.2392156863, alpha: 1)))
                                .padding(.all, 10)
                                .background(Color.white)
                                .clipShape(Circle())
                            
                            Text(" Total de décès ")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundColor(.black)
                            
                            
                            Text("\(i.TotalDeaths)")
                                .font(.system(size: 21, weight: .bold, design: .rounded))
                                .foregroundColor(Color(#colorLiteral(red: 0.8980392157, green: 0.8980392157, blue: 0.8980392157, alpha: 1)))
                            
                            
                        }
                        
                        
                        
                        
                    }
                    
                    
                    
                }
                
                
                
            }
            
            HStack {
                
                ForEach(resultats, id: \.id){ i in
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 8).frame(width:self.width, height:self.width).foregroundColor(.orange)
                            .shadow(radius: 10)
                        
                        VStack{
                            
                            Image(systemName: "person.fill")
                                .foregroundColor(Color(#colorLiteral(red: 0.07843137255, green: 0.1294117647, blue: 0.2392156863, alpha: 1)))
                                .padding(.all, 10)
                                .background(Color.white)
                                .clipShape(Circle())
                            
                            Text("Nouveaux cas")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundColor(.black)
                            
                            Text("de rémission")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundColor(.black)
                            
                            Text("\(i.NewRecovered)")
                                .font(.system(size: 21, weight: .bold, design: .rounded))
                                .foregroundColor(Color(#colorLiteral(red: 0.8980392157, green: 0.8980392157, blue: 0.8980392157, alpha: 1)))
                            
                            
                        }
                        

                        
                    }
                    
                    
                    
                }
                
                ForEach(resultats, id: \.id){ i in
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 8).frame(width:self.width, height:self.width).foregroundColor(Color(#colorLiteral(red: 0.07843137255, green: 0.1294117647, blue: 0.2392156863, alpha: 1)))
                            .shadow(radius: 10)
                        
                        VStack{
                            
                            Image(systemName: "person.3.fill")
                                .foregroundColor(.orange)
                                .padding(.all, 10)
                                .background(Color.white)
                                .clipShape(Circle())
                            
                            Text("  Total de cas  ")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundColor(Color(#colorLiteral(red: 0.8980392157, green: 0.8980392157, blue: 0.8980392157, alpha: 1)))
                            
                            Text("   de rémission  ")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundColor(Color(#colorLiteral(red: 0.8980392157, green: 0.8980392157, blue: 0.8980392157, alpha: 1)))
                            
                            Text("\(i.TotalRecovered)")
                                .font(.system(size: 21, weight: .bold, design: .rounded))
                                .foregroundColor(.green)
                            
                            
                        }
                        
   
                    }
                    
                    
                    
                }
                
                
                
            }
            
            Spacer()
            
            
        }
            
        .onAppear(perform: loadGlobalData)
        
    }
    
    func loadGlobalData(){
        
        guard let url=URL(string: "https://api.covid19api.com/summary") else{
            print("Url non valide")
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        request.setValue("5cf9dfd5-3449-485e-b5ae-70a60e997864", forHTTPHeaderField: "X-Access-Token")
        
        URLSession.shared.dataTask(with: request){ data, response, error in
            if let data = data{
                
                if let decodedResponse = try? JSONDecoder().decode(Response.self, from: data){
                    
                    DispatchQueue.main.async {
                        
                        self.resultats = [decodedResponse.Global]
                        
                        print(decodedResponse)
                    }
                    
                }
                
                return
                
            }
            
            print("Fetch failed: \(error?.localizedDescription ?? "Unknown error") ")
            
        }.resume()
        
    }
    
}

struct InfoGlobal_Previews: PreviewProvider {
    static var previews: some View {
        InfoGlobal()
    }
}

