//
//  ContentView.swift
//  Covid Info App
//
//  Created by Student Supinfo on 30/03/2021.
//  Copyright © 2021 Paul Yvan TCHINDJI YOUMBI. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    
    @State var results = [Result]()
    
    @State var resultats = [GlobalStats]()
    
    
    
    var body: some View {
        
        
        
        TabView {
            
            InfoGlobal()
                
                .tabItem{
                    Image(systemName: "square.grid.2x2")
                    Text("Dashboard")
                        .font(.system(size: 16, design: .rounded))
            }
            
            NavigationView{
                
                
                CountryListView()
                    
                    
                    .navigationBarTitle("Informations")
                                        
                    .navigationBarItems(trailing: EditButton())
                                
            }
            .tabItem{
                Image(systemName: "list.dash")
                Text("Liste")
                    .font(.system(size: 16, design: .rounded))
                
            }
            
            
        }.accentColor(Color(#colorLiteral(red: 0.07843137255, green: 0.1294117647, blue: 0.2392156863, alpha: 1)))
        
        
        
    }
    
    
    
    
    
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
